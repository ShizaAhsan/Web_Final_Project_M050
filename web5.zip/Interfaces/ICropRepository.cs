﻿namespace Web_Final_Project_sem_5.Interfaces
{
    public class ICropRepository
    {
    }
}
