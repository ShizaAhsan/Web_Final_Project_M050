﻿namespace Web_Final_Project_sem_5.Models
{
    public class Farm
    {
    }
}
