﻿namespace Web_Final_Project_sem_5.Repositories
{
    public class CropRepository
    {
    }
}
